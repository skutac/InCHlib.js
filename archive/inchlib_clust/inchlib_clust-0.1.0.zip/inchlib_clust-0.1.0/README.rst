inchlib_clust: Clustering and data preparation for InCHlib
==========================