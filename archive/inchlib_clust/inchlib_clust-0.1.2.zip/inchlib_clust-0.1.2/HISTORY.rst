Changelog for pem
=================

0.1.2 (28-08-2014)
------------------
   - export_cluster_heatmap_as_html() function added

0.1.1 (08-07-2014)
------------------
   - Minor fixes in functioning
   - There is further no need to use independent hcluster library

0.1.0 (05-02-2014)
------------------
   - Initial release.