Changelog for pem
=================

0.1.4 (26-03-2015)
------------------
    - added functionality to add alternative data to the InCHlib format
	- bug fixes and minor improvements

0.1.3 (18-09-2014)
------------------
   - added functionality to process data with missing/unknown values
   - added functionality to add column metadata for clustered data
   - bug fixes and improvements

0.1.2 (28-08-2014)
------------------
   - export_cluster_heatmap_as_html() function added

0.1.1 (08-07-2014)
------------------
   - Minor fixes in functioning
   - There is further no need to use independent hcluster library

0.1.0 (05-02-2014)
------------------
   - Initial release.